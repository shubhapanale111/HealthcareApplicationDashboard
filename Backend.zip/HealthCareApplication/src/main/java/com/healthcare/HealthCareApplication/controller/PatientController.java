package com.healthcare.HealthCareApplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.healthcare.HealthCareApplication.entiry.Patient;
import com.healthcare.HealthCareApplication.repo.PatientRepository;

@RestController
@RequestMapping("/patients")
@CrossOrigin("http://localhost:3000")
public class PatientController {
    @Autowired
    private PatientRepository patientRepository;

    // Create a new patient
    @PostMapping("/")
    public Patient createPatient(@RequestBody Patient patient) {
        return patientRepository.save(patient);
    }

    // Get a patient by ID
    @GetMapping("/{id}")
    public Optional<Patient> getPatient(@PathVariable Long id) {
        return patientRepository.findById(id);
    }

    // Get all patients
    @GetMapping("/")
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    // Update a patient
    @PutMapping("/{id}")
    public Patient updatePatient(@PathVariable Long id, @RequestBody Patient patient) {
        if (patientRepository.existsById(id)) {
            patient.setId(id);
            return patientRepository.save(patient);
        }
        return null; // Handle not found scenario
    }

    // Delete a patient by ID
    @DeleteMapping("/{id}")
    public void deletePatient(@PathVariable Long id) {
        patientRepository.deleteById(id);
    }
}
