package com.healthcare.HealthCareApplication.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.healthcare.HealthCareApplication.entiry.Patient;



public interface PatientRepository extends JpaRepository<Patient, Long> {
}
